// $(function(){
//     let menuColapseItems = $(".nav-item.has-submenu");
//     menuColapseItems.each(function(){
//         $(this).on('click',function(){
//             $(".nav-item.has-submenu").each(function(){
//                 $(this).addClass('colapse');
//                 $(this).removeClass('active');
//                 $(this).find('.submenu').addClass('collapse');
//             });
//             $(this).removeClass('colapse');
//             $(this).addClass('active');
//             $(this).find('.submenu.collapse').removeClass('collapse');
//         });
//     })
// })

$(function(){
    getActiveMenu();
    $(".nav-item.has-submenu").each(function(){
        $(this).on('click',function(){
            $a = $(this).children('a');
            
            if ($a.hasClass('collapsed')) {
                $(this).removeClass('active');
                $a.children('.drop-icon').children('i').addClass('bi bi-chevron-down')
                $a.children('.drop-icon').children('i').removeClass('bi bi-chevron-up')
            }else{
                $(this).addClass('active');
                $a.children('.drop-icon').children('i').removeClass('bi bi-chevron-down')
                $a.children('.drop-icon').children('i').addClass('bi bi-chevron-up')
            }
        })
    })

    // all you need to get started
    $('pre').litelighter();

    // toggle examples on/off
    var on = true;
    $('#toggleOnOff').click(function(e){
        e.preventDefault();
        if(on) $('pre.example').litelighter('disable');
        else $('pre.example').litelighter('enable');
        on = !on;
    });

    // toggle light to dark themes
    var light = false;
    $('#toggleLightDark').click(function(e){
        e.preventDefault();
        if(light) $('pre.example').litelighter('option','style','dark');
        else $('pre.example').litelighter('option','style','light');
        light = !light;
    });

        $(".validate-form").on("submit",function(e){
            let totalPay =Number($("#amount").val());
            let totalSplitPay = 0;
            $(".multiinput-amount").each(function(element){
                totalSplitPay = totalSplitPay + Number($(this).val());
            })
            if (totalSplitPay != totalPay) {
                alert("جمع مبالغ تسهیم با مبلغ کل تراکنش همخوانی ندارد");
                e.preventDefault();
            }
            return true;
        })
    
})


function getActiveMenu(){
    loc = window.location.pathname;
    $(".nav-link").each(function(){
        if (loc == $(this).attr('href')) {
            $(".nav-link").removeClass('active');
            $(this).parents('.submenu').removeClass('collapse').addClass('show');
            $(this).addClass('active');
        }
    })
}
var rowCount = $(".multi-row").length;

console.log(rowCount);

function generateNewRowID(){
    Id = Date.now() + Math.random();
    return Math.round(Id);
}
let rowId = generateNewRowID();
function addNewRow() {

    if (rowCount == 9) {
        alert('حداکثر 9 ردیف میتوان ایجاد نمود.');
        return false;
    }
    let template = `<div class="row multi-row" data-row-id="${rowId}">
    <div class="col-3">
        <div class="form-element">
            <input type="text" name="Account[${rowId}][Amount]"  class="form-control form-control-sm multiinput-amount" data-validation="required"/>
        </div>
    </div>
    <div class="col-3">
        <div class="form-element">
        <input type="text" name="Account[${rowId}][IBAN]"  class="form-control form-control-sm" data-validation="required"/>
        </div>
        
    </div>
    <div class="col-3">
        <div class="form-element">
        <input type="text" name="Account[${rowId}][PayId]"  class="form-control form-control-sm" data-validation="required"/>
        </div>
        
    </div>
    <div class="col-3">
        <button class="btn btn-danger" type="button" onclick="deleteRow('${rowId}')"><i class="bi bi-trash text-light"></i></button>
    </div>
</div>`;

$('#multi-row-base').append(template);
rowCount = rowCount + 1;
rowId = generateNewRowID();
}

function deleteRow(row) {
    if (rowCount != 1) {
        rowCount = rowCount - 1;
        $(`[data-row-id="${row}"]`).remove();
    }else{
        alert('حداقل یک ردیف لازم است');
    }
    
}

function  showCode() {
    if ($('.code-viewer-section').hasClass('active')) {
        $('.code-viewer-section').removeClass('active');
    }else{
        $('.code-viewer-section').addClass('active');
    }
    
}

