<?php
require_once '../PecRequestClass.php';
$pecRequest = new PecRequestClass();
$res = false;
$success = false;
$url = 'https://pgwservices.pec.ir/api/PGWReport/GetSaleReport';
// $url = 'http://localhost:3000/api/test';
$server_output = '';
$startDate = '1402/09/01';
$endDate = '1402/09/15';
if ($_POST) {
    if ($_POST['username'] == '' || $_POST['password'] == '' || $_POST['FromDate'] == '' || $_POST['ToDate'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{

        // تبدیل اطلاعات خواسته شده 
        $username = $_POST['username'];
        $password = $_POST['password'];
        $authToken = base64_encode($username.'|'.$password);
        $dateStart = DateTime::createFromFormat("Y/m/d",$pecRequest->changeDate($_POST['FromDate']));
        $startDate = $dateStart->format('Y-m-d H:i:s');
        $dateEnd = DateTime::createFromFormat("Y/m/d",$pecRequest->changeDate($_POST['ToDate']));
        $endDate = $dateEnd->format('Y-m-d H:i:s');
        
         // بازه زمانی نباید بیشتر از سی روز باشد
        $datediff =  strtotime($endDate) - strtotime($startDate);
         if (($datediff / (60 * 60 * 24)) > 30 ) {
            $pecRequest->errorMsg = 'بازه زمانی نباید بیشتر از یکماه باشد.';
            $res = $pecRequest->alertMsg();
         }elseif(($datediff / (60 * 60 * 24)) < 0 ){
            $pecRequest->errorMsg = 'بازه زمانی انتخابی شما صحیح نمیباشد';
            $res = $pecRequest->alertMsg();
         }else{

            $data = [
                "FromDate" => $startDate,
                "ToDate" => $endDate,
                "RRN" => isset($_POST['RRN']) ? $_POST['RRN'] : '',
                "OrderId" => isset($_POST['OrderId']) ? $_POST['OrderId'] : '',
                "Token" => isset($_POST['Token']) ? $_POST['Token'] : '',
            ];
            $payload = json_encode( $data );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$payload);  //Post Fields
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
            // این دو خط برای اجرا در سرور لوکال است و در هنگام اجرا در سرور اصلی باید حذف شوند
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            //
    
            $headers = [
                'Content-Type: application/json',
                'Authorization:Basic '.$authToken,
            ];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $server_output = json_decode(curl_exec ($ch));
            curl_close ($ch);
         }
        
        

    }
    
}

?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">
    <header class="header">
        <div class="d-flex justify-content-center flex-wrap align-items-center h-100">
            <h1 class="header-title"> مشاهده لیست سفارشات  </h1>
        </div>
    </header>

    <?= include '../sidebar.php' ?>
    <div class="content">
        <?php
            if ($res) {
                echo $res;
            }

            if ($server_output):
        ?>
                <div class="col-12 py-3 mt-2 border rounded">
                    <div class="code-viewer-section active">
			        <h4 id="Examples" style="direction:rtl; text-align:right;">مقادیر برگشتی</h4>
                    <pre class="code example" data-lllanguage="php" data-llstyle="dark">
						<?php
						    
								echo "\r\n Status :".$server_output->Status;
                                echo "\r\n Message :".$server_output->Message;
                                echo "\r\n Data :".print_r($server_output->Data);							
						?>
					</pre>
			        </div>
                </div>
        <?php endif ?>
        <form action="#" id="saleRequesForm" name="saleRequestForm" method="post" autocomplete="off">
            <div class="d-flex justify-content-between">
                <h3 class="section-title py-2">ارسال درخواست  خرید با شناسه حساب دولتی </h3>
                <div class="buttons-section col-6 d-flex gap-3 justify-content-end">
                    <button type="sumbit" class="btn btn-success">ارسال اطلاعات</button>
                    <button type="reset" class="btn btn-primary">بازنشانی فرم</button>
                    <button type="button" class="btn btn-warning" onclick="showCode()">نمایش کد ها</button>
                    <a href="https://pgw.pec.ir/IPGDocs/IPGOnlineMultiplexSale-Government-New.pdf" class="btn btn-info">دانلود داکیومنت ها</a>
                </div>
            </div>
        <div class="container-fluid section-container">
            
            <!-- دریافت اطلاعات از طریق فرم -->
            <section class="col-lg-6 col-12">
                
                    <div class="form-element col-12">
                        <label for="username">username :</label>
                        <input type="text" name="username" id="username" class="form-control" data-validation="required" value="<?= (isset($_POST['username'])) ? $_POST['username']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="password"> password :</label>
                        <input type="text" name="password" id="password" class="form-control" data-validation="required" value="<?= (isset($_POST['password'])) ? $_POST['password']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="FromDate"> از تاریخ :</label>
                        <input type="text" name="FromDate" placeholder="2023/03/15" id="FromDate" class="form-control" data-validation="required" value="<?= (isset($_POST['FromDate'])) ? $_POST['FromDate']:$startDate ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="ToDate">تا تاریخ :</label>
                        <input type="text" name="ToDate" placeholder="2023/05/15" id="ToDate" class="form-control" data-validation="required" value="<?= (isset($_POST['ToDate'])) ? $_POST['ToDate']:$endDate ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="RRN">شماره مرجع</label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="RRN" id="RRN" class="form-control"  value="<?= (isset($_POST['RNN'])) ? $_POST['RRN']:'' ?>"  />
                    </div>

                    <div class="form-element col-12">
                        <label for="OrderId"> شماره سفارش </label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="OrderId" id="OrderId" class="form-control"  value="<?= (isset($_POST['OrderId'])) ? $_POST['OrderId']:'' ?>" />
                    </div>
                    <div class="form-element col-12">
                        <label for="OrderId"> شماره تراکنش </label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="Token" id="Token" class="form-control"  value="<?= (isset($_POST['Token'])) ? $_POST['Token']:'' ?>" />
                    </div>
                
            </section>
       
            <!-- نمایش کد های راهنما -->
            <section class="col-lg-6 col-12 code-viewer-section">
                <div id="source-code-base" class="pr-4">
                    <h4 class="title">index.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
                        require_once '../PecRequestClass.php';
$pecRequest = new PecRequestClass();
$res = false;
$success = false;
$url = 'https://pgwservices.pec.ir/api/PGWReport/GetSaleReport';
// $url = 'http://localhost:3000/api/test';
$server_output = '';
if ($_POST) {
    if ($_POST['username'] == '' || $_POST['password'] == '' || $_POST['FromDate'] == '' || $_POST['ToDate'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{

        // تبدیل اطلاعات خواسته شده 
        $username = $_POST['username'];
        $password = $_POST['password'];
        $authToken = base64_encode($username.'|'.$password);
        $dateStart = DateTime::createFromFormat("Y/m/d",$pecRequest->changeDate($_POST['FromDate']));
        $startDate = $dateStart->format('Y-m-d H:i:s');
        $dateEnd = DateTime::createFromFormat("Y/m/d",$pecRequest->changeDate($_POST['ToDate']));
        $endDate = $dateEnd->format('Y-m-d H:i:s');
        
         // بازه زمانی نباید بیشتر از سی روز باشد
        $datediff =  strtotime($endDate) - strtotime($startDate);
         if (($datediff / (60 * 60 * 24)) > 30 ) {
            $pecRequest->errorMsg = 'بازه زمانی نباید بیشتر از یکماه باشد.';
            $res = $pecRequest->alertMsg();
         }elseif(($datediff / (60 * 60 * 24)) < 0 ){
            $pecRequest->errorMsg = 'بازه زمانی انتخابی شما صحیح نمیباشد';
            $res = $pecRequest->alertMsg();
         }else{

            $data = [
                "FromDate" => $startDate,
                "ToDate" => $endDate,
                "RRN" => isset($_POST['RRN']) ? $_POST['RRN'] : '',
                "OrderId" => isset($_POST['OrderId']) ? $_POST['OrderId'] : '',
                "Token" => isset($_POST['Token']) ? $_POST['Token'] : '',
            ];
            $payload = json_encode( $data );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$payload);  //Post Fields
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
            // این دو خط برای اجرا در سرور لوکال است و در هنگام اجرا در سرور اصلی باید حذف شوند
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            //
    
            $headers = [
                'Content-Type: application/json',
                'Authorization:Basic '.$authToken,
            ];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $server_output = json_decode(curl_exec ($ch));
            curl_close ($ch);
         }
        
        

    }
    
}
                        </pre>

                                        </div>
            </section>


        </div>
    </form>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter-extra.js"></script>
<script src="/js/template.js"></script>
</body>
</html>