<?php
require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res = false;
$success = false;
if(isset($_POST['callback'])){
    $callback = $_POST['callback'];
}else{
    $callback = 'http://localhost/billpayment/callback.php';
}
if ($_POST) {
    if ($_POST['pin'] == '' || $_POST['orderId'] == '' || $_POST['BillId'] == '' || $_POST['PayId'] == '' || $_POST['callback'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        // دریافت اطلاعات از فرم
        $pecRequest->pin = $_POST['pin'];
        $pecRequest->callbackUrl = $_POST['callback'];
        $orderId = $_POST['orderId'];
        $billId = $_POST['BillId'];
        $payId = $_POST['PayId'];
        $additionalData = $_POST['additionalData'];
        $orginator = $_POST['orginator'];
        
        // ارسال درخواست
        $res = $pecRequest->payBillRequest($orderId,$billId,$payId,$additionalData,$orginator); 
        if ($res == false) {
				$res = $pecRequest->alertMsg();
        }
        else{
            $success = true;
        }
    }
    
}

?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">
    <header class="header">
        <div class="d-flex justify-content-center flex-wrap align-items-center h-100">
            <h1 class="header-title">راهنمای سرویس پرداخت قبوض</h1>
        </div>
    </header>

    <?= include '../sidebar.php' ?>
    <div class="content">
        <?php
            if ($res) {
                echo $res;
            }
        ?>
        <form action="#" id="saleRequesForm" name="saleRequestForm" method="post" autocomplete="off">
            <div class="d-flex justify-content-between">
                <h3 class="section-title py-2">ارسال درخواست پراخت قبض</h3>
                <div class="buttons-section col-6 d-flex gap-3 justify-content-end">
                    <button type="sumbit" class="btn btn-success">ارسال اطلاعات</button>
                    <button type="reset" class="btn btn-primary">بازنشانی فرم</button>
                    <button type="button" class="btn btn-warning" onclick="showCode()">نمایش کد ها</button>
                    <a href="https://pgw.pec.ir/IPGDocs/10013101-sw1.pdf" class="btn btn-info">دانلود داکیومنت ها</a>
                </div>
            </div>
        <div class="container-fluid section-container">
            
            <!-- دریافت اطلاعات از طریق فرم -->
            <section class="col-lg-6 col-12">
                
                    <div class="form-element col-12">
                        <label for="pin">کد پذیرنده (pin) :</label>
                        <input type="text" name="pin" id="pin" class="form-control" data-validation="required" value="<?= (isset($_POST['pin'])) ? $_POST['pin']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="orderId">شماره سفارش  (orderId) :</label>
                        <input type="text" name="orderId" id="orderId" class="form-control" data-validation="required" value="<?= (isset($_POST['orderId'])) ? $_POST['orderId']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="billId">شناسه قبض (BillId):</label>
                        <input type="text" name="BillId" id="billId" class="form-control" data-validation="required" value="<?= (isset($_POST['BillId'])) ? $_POST['BillId']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="payId">شناسه پرداخت (PayId):</label>
                        <input type="text" name="PayId" id="payId" class="form-control" data-validation="required" value="<?= (isset($_POST['PayId'])) ? $_POST['PayId']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="callback">آدرس برگشتی (callback):</label>
                        <input type="text" name="callback" id="callback" class="form-control" data-validation="required" value="<?= (isset($_POST['callback'])) ? $_POST['callback']:$callback ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="additionalData">مقادیر اضافی (additionalData) : </label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="additionalData" id="additionalData" class="form-control" data-validation="required" value="<?= (isset($_POST['additionalData'])) ? $_POST['additionalData']:'' ?>"  />
                    </div>

                    <div class="form-element col-12">
                        <label for="orginator">اطلاعات خریدار (orginator):</label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="orginator" id="orginator" class="form-control" data-validation="required" value="<?= (isset($_POST['orginator'])) ? $_POST['orginator']:'' ?>" />
                    </div>
                
            </section>
       
            <!-- نمایش کد های راهنما -->
            <section class="col-lg-6 col-12 code-viewer-section">
                <div id="source-code-base" class="pr-4">
                    <h4 class="title">index.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
        //بارگذاری کلاس مربوط به انجام عملیات های پرداخت
        require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res = false;
$success = false;
if(isset($_POST['callback'])){
    $callback = $_POST['callback'];
}else{
    $callback = 'http://localhost/billpayment/callback.php';
}
if ($_POST) {
    if ($_POST['pin'] == '' || $_POST['orderId'] == '' || $_POST['BillId'] == '' || $_POST['PayId'] == '' || $_POST['callback'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        // دریافت اطلاعات از فرم
        $pecRequest->pin = $_POST['pin'];
        $pecRequest->callbackUrl = $_POST['callback'];
        $orderId = $_POST['orderId'];
        $billId = $_POST['BillId'];
        $payId = $_POST['PayId'];
        $additionalData = $_POST['additionalData'];
        $orginator = $_POST['orginator'];
        
        // ارسال درخواست
        $res = $pecRequest->payBillRequest($orderId,$billId,$payId,$additionalData,$orginator); 
        if ($res == false) {
				$res = $pecRequest->alertMsg();
        }
        else{
            $success = true;
        }
    }
    
}
                        </pre>

                        <h4 id="Examples">PecRequestClass.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
// سرویس پرداخت قبض
    public function payBillRequest($orderId,$billId,$payId,$additionalData="",$orginator=""){
        $this->url = "https://pec.shaparak.ir/NewIPGServices/Bill/BillService.asmx?wsdl";
        $this->orderId = $orderId;
        $params = array (
			"LoginAccount" => $this->pin,
			"BillId" => $billId,
            "PayId" => $payId,
			"OrderId" => $orderId,
            "Amount" => '',
			"CallBackUrl" => $this->callbackUrl,
            "AdditionalData" => $additionalData,
            "Originator" => $orginator, 
	    );

        // در این مرحله میتوانید اطلاعات قبل از ارسال را ذخیره سازی کنید.

        $client = new SoapClient ( $this->url );
        try {
            $result = $client->BillPaymentRequest ( array (
                    "requestData" => $params 
            ));
            if ($result->BillPaymentRequestResult->Token && $result->BillPaymentRequestResult->Status === 0) {
                // توکن دریافت شده را میتوانید در این مرحله به تراکنش مورد نظر مرتبط نموده و ذخیره سازی کنید.
                // $token = $result->BillPaymentRequestResult->Token;
                header ( "Location: https://pec.shaparak.ir/NewIPG/?Token=" . $result->BillPaymentRequestResult->Token ); /* Redirect browser */
                exit ();
            }
            elseif ( $result->BillPaymentRequestResult->Status  != '0') {
                $err_msg = "(<strong> کد خطا : " . $result->BillPaymentRequestResult->Status . "</strong>) " .
                $result->BillPaymentRequestResult->Message ;
                $this->errorMsg = $err_msg;
                return false;
            }
        } catch ( Exception $ex ) {
            $this->errorMsg =  $ex->getMessage();
        }
            
    }

                        </pre>
                </div>
            </section>


        </div>
    </form>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter-extra.js"></script>
<script src="/js/template.js"></script>
</body>
</html>