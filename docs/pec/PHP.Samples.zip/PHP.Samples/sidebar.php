<aside class="sidebar">
        <div class="head-logo col-12 py-2 d-flex justify-content-center">
            <img src="/images/pec-logo-new.png" alt="" class="w-50">
        </div>
        <nav class="sidebar-menu card py-2 mb-4">
            <ul class="nav flex-column" id="nav_accordion">
                <li class="nav-item has-submenu colapse" >
                    <a href="#menu-item-1" class="nav-link w-100" for="menu-item-1" data-bs-toggle="collapse" aria-expanded="true" aria-bs-controls="menu-item-1">
                        <span><i class="bi bi-cart"></i> سرویس درگاه خرید کالا و خدمات </span>
                        <span class="drop-icon"><i class="bi bi-chevron-down"></i></span>
                    </a>
                    <ul class="submenu collapse" id="menu-item-1">
                        <li><a class="nav-link" href="/salerequest/index.php">ارسال درخواست خرید کالا و خدمات</a></li>
                        <li><a class="nav-link" href="/salerequest/confirm.php">تایید تراکنش</a></li>
                        <li><a class="nav-link" href="/salerequest/cancelRequest.php">لغو تراکنش</a></li>
                    </ul>
                </li>
                <li class="nav-item has-submenu colapse" >
                    <a href="#menu-item-5" class="nav-link w-100" for="menu-item-5" data-bs-toggle="collapse" aria-expanded="true" aria-bs-controls="menu-item-5">
                        <span><i class="bi bi-cart"></i> سرویس خرید با تسهیم آنلاین </span>
                        <span class="drop-icon"><i class="bi bi-chevron-down"></i></span>
                    </a>
                    <ul class="submenu collapse" id="menu-item-5">
                        <li><a class="nav-link" href="/sale-tashim/index.php">ارسال درخواست خرید</a></li>
                    </ul>
                </li>
                <li class="nav-item has-submenu colapse" >
                    <a href="#menu-item-2" class="nav-link w-100" for="menu-item-2" data-bs-toggle="collapse" aria-expanded="true" aria-bs-controls="menu-item-2">
                        <span><i class="bi bi-cart"></i> سرویس خرید با شناسه حساب دولتی </span>
                        <span class="drop-icon"><i class="bi bi-chevron-down"></i></span>
                    </a>
                    <ul class="submenu collapse" id="menu-item-2">
                    <li><a class="nav-link" href="/gov/index.php"> خرید با شناسه حساب دولتی</a></li>
                    <li><a class="nav-link" href="/gov/multiplex.php">پرداخت وجوه دولتی با امکان تسهیم چند حسابی</a></li>
                    </ul>
                </li>
                <li class="nav-item has-submenu colapse" >
                    <a href="#menu-item-3" class="nav-link w-100" for="menu-item-3" data-bs-toggle="collapse" aria-expanded="true" aria-bs-controls="menu-item-3">
                        <span><i class="bi bi-cart"></i> سرویس پرداخت قبوض </span>
                        <span class="drop-icon"><i class="bi bi-chevron-down"></i></span>
                    </a>
                    <ul class="submenu collapse" id="menu-item-3">
                        <li><a class="nav-link" href="/billpayment/index.php"> پرداخت قبض</a></li>
                    </ul>
                </li>
                <li class="nav-item has-submenu colapse" >
                    <a href="#menu-item-4" class="nav-link w-100" for="menu-item-4" data-bs-toggle="collapse" aria-expanded="true" aria-bs-controls="menu-item-4">
                        <span><i class="bi bi-cart"></i>سرویس خرید شارژ موبایل</span>
                        <span class="drop-icon"><i class="bi bi-chevron-down"></i></span>
                    </a>
                    <ul class="submenu collapse" id="menu-item-4">
                        <li><a class="nav-link" href="/mobilecharge/index.php"> خرید شارژ</a></li>
                    </ul>
                </li>

                
            </ul>
            </nav>
    </aside>