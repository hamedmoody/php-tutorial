<?php
require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res = false;
$success = false;
if(isset($_POST['callback'])){
    $callback = $_POST['callback'];
}else{
    $callback = 'http://localhost/sale-tashim/callback.php';
}
if ($_POST) {
    if ($_POST['pin'] == '' || $_POST['orderId'] == '' || $_POST['amount'] == '' || $_POST['callback'] == '' ||  $_POST['Account'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        // دریافت و اعتبار سنجی اطلاعات مربوط به تسهیم
        $account = [];
        $postAcccount = $_POST['Account'];
        $count = 0;
        $validate = true;
        foreach ($postAcccount as $key => $value) {
                if ($value == '') {
                    $validate = false;
                }
            $account[$count] = $value;
            $count++;
        }
        if (!$validate) {
            $pecRequest->errorMsg = 'اطلاعات مربوط به مشخصات حساب ها را تکمیل نمایید';
            $res = $pecRequest->alertMsg();
        }else{
            // دریافت اطلاعات از فرم
            $pecRequest->pin = $_POST['pin'];
            $pecRequest->callbackUrl = $_POST['callback'];
            $orderId = $_POST['orderId'];
            $amount = $_POST['amount'];
            $orginator = $_POST['orginator'];
            
            // ارسال درخواست
            $res = $pecRequest->onlineMultiplexedSalePaymentService($orderId,$amount,$account,$orginator); 
            if ($res == false) {
                    $res = $pecRequest->alertMsg();
            }
            else{
                $success = true;
            }
        }
        
    }
    
}

?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">
    <header class="header">
        <div class="d-flex justify-content-center flex-wrap align-items-center h-100">
            <h1 class="header-title">پرداخت وجوه دولتی با امکان تسهیم چند حسابی</h1>
        </div>
    </header>

    <?= include '../sidebar.php' ?>
    <div class="content">
        <?php
            if ($res) {
                echo $res;
            }
        ?>
        <form action="#" class="validate-form" id="saleRequesForm" name="saleRequestForm" method="post" autocomplete="off">
            <div class="d-flex justify-content-between">
                <h3 class="section-title py-2"> راهنمای سرویس خرید با امکان تسهیم آنلاین </h3>
                <div class="buttons-section col-6 d-flex gap-3 justify-content-end">
                    <button type="sumbit" class="btn btn-success">ارسال اطلاعات</button>
                    <button type="reset" class="btn btn-primary">بازنشانی فرم</button>
                    <button type="button" class="btn btn-warning" onclick="showCode()">نمایش کد ها</button>
                    <a href="https://pgw.pec.ir/IPGDocs/10016104-onlineWithIBAN-sw1.pdf" class="btn btn-info">دانلود داکیومنت ها</a>
                </div>
            </div>
        <div class="container-fluid section-container">
            
            <!-- دریافت اطلاعات از طریق فرم -->
            <section class="col-lg-8 col-12">
                
                    <div class="form-element col-12">
                        <label for="pin">کد پذیرنده (pin) :</label>
                        <input type="text" name="pin" id="pin" class="form-control" data-validation="required" value="<?= (isset($_POST['pin'])) ? $_POST['pin']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="orderId">شماره سفارش  (orderId) :</label>
                        <input type="text" name="orderId" id="orderId" class="form-control" data-validation="required" value="<?= (isset($_POST['orderId'])) ? $_POST['orderId']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="form-element col-12">
                        <label for="amount">مبلغ تراکنش (amount):</label>
                        <input type="text" name="amount" id="amount" class="form-control" data-validation="required" value="<?= (isset($_POST['amount'])) ? $_POST['amount']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="callback">آدرس برگشتی (callback):</label>
                        <input type="text" name="callback" id="callback" class="form-control" data-validation="required" value="<?= (isset($_POST['callback'])) ? $_POST['callback']:$callback ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>

                    <div class="form-element col-12">
                        <label for="orginator">اطلاعات خریدار (orginator):</label>
                        <div class="hint">غیر ضروری</div>
                        <input type="text" name="orginator" id="orginator" class="form-control" data-validation="required" value="<?= (isset($_POST['orginator'])) ? $_POST['orginator']:'' ?>" />
                    </div>
                    
                    <fieldset class="MYFieldset">
                        <legend class="MyLegend">مشخصات حساب ها</legend>
                        
                        <div class="col-12 " id="multi-row-base">
                            <div class="d-flex justify-content-center my-2">
                                <div class="col-3">مبلغ (ریال)</div>
                                <div class="col-3">شماره شبا</div>
                                <div class="col-3">شناسه پرداخت</div>
                                <div class="col-3"><button type="button" class="btn btn-success" onclick="addNewRow()">اضافه کردن سطر جدید</button></div>
                            </div>
                            <?php 
                            if (isset($_POST['Account'])):
                                foreach ($_POST['Account'] as $key => $value):
                            ?>
                                <div class="row multi-row" data-row-id="<?= $key ?>">
                                    <div class="col-3">
                                        <div class="form-element">
                                            <input type="text" name="Account[<?= $key ?>][Amount]"  class="form-control form-control-sm multiinput-amount" data-validation="required" value="<?= $_POST['Account'][$key]['Amount']?>"/>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-element">
                                        <input type="text" name="Account[<?= $key ?>][IBAN]"  class="form-control form-control-sm" data-validation="required" value="<?= $_POST['Account'][$key]['IBAN']?>"/>
                                        </div>
                                        
                                    </div>
                                    <div class="col-3">
                                        <div class="form-element">
                                        <input type="text" name="Account[<?= $key ?>][PayId]"  class="form-control form-control-sm" data-validation="required" value="<?= $_POST['Account'][$key]['PayId']?>" />
                                        </div>
                                        
                                    </div>
                                    <div class="col-3">
                                        <button class="btn btn-danger" type="button" onclick="deleteRow(0)"><i class="bi bi-trash text-light"></i></button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php else: ?>
                            <div class="row multi-row" data-row-id="0">
                                <div class="col-3">
                                    <div class="form-element">
                                        <input type="text" name="Account[0][Amount]"  class="form-control form-control-sm multiinput-amount" data-validation="required"/>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-element">
                                    <input type="text" name="Account[0][IBAN]"  class="form-control form-control-sm" data-validation="required"/>
                                    </div>
                                    
                                </div>
                                <div class="col-3">
                                    <div class="form-element">
                                    <input type="text" name="Account[0][PayId]"  class="form-control form-control-sm" data-validation="required"/>
                                    </div>
                                    
                                </div>
                                <div class="col-3">
                                    <button class="btn btn-danger" type="button" onclick="deleteRow(0)"><i class="bi bi-trash text-light"></i></button>
                                </div>
                            </div>
                            <?php endif;?>
                            
                        </div>
                        

                    </fieldset>
                
            </section>
       
            <!-- نمایش کد های راهنما -->
            <section class="col-lg-4 col-12 code-viewer-section">
                <div id="source-code-base" class="pr-4">
                    <h4 id="Examples">index.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
        //بارگذاری کلاس مربوط به انجام عملیات های پرداخت
        require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res = false;
$success = false;
if(isset($_POST['callback'])){
    $callback = $_POST['callback'];
}else{
    $callback = 'http://localhost/sale-tashim/callback.php';
}
if ($_POST) {
    if ($_POST['pin'] == '' || $_POST['orderId'] == '' || $_POST['amount'] == '' || $_POST['callback'] == '' ||  $_POST['Account'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        // دریافت و اعتبار سنجی اطلاعات مربوط به تسهیم
        $account = [];
        $postAcccount = $_POST['Account'];
        $count = 0;
        $validate = true;
        foreach ($postAcccount as $key => $value) {
                if ($value == '') {
                    $validate = false;
                }
            $account[$count] = $value;
            $count++;
        }
        if (!$validate) {
            $pecRequest->errorMsg = 'اطلاعات مربوط به مشخصات حساب ها را تکمیل نمایید';
            $res = $pecRequest->alertMsg();
        }else{
            // دریافت اطلاعات از فرم
            $pecRequest->pin = $_POST['pin'];
            $pecRequest->callbackUrl = $_POST['callback'];
            $orderId = $_POST['orderId'];
            $amount = $_POST['amount'];
            $orginator = $_POST['orginator'];
            
            // ارسال درخواست
            $res = $pecRequest->onlineMultiplexedSalePaymentService($orderId,$amount,$account,$orginator); 
            if ($res == false) {
                    $res = $pecRequest->alertMsg();
            }
            else{
                $success = true;
            }
        }
        
    }
    
}
                        </pre>

                        <h4 id="Examples">PecRequestClass.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
    // سرویس خرید با امکان تسهیم آنلاین

    public function onlineMultiplexedSalePaymentService($orderId,$amount,$accounts,$orginator){
        $this->url = "https://pec.shaparak.ir/NewIPGServices/MultiplexedSale/OnlineMultiplexedSalePaymentService.asmx?wsdl";
        // اطلاعات اضافی باید خالی باشد.
        $additionalData = "";
        $this->orderId = $orderId;
        $params = array (
			"LoginAccount" => $this->pin,
			"Amount" => $amount,
			"OrderId" => $orderId,
			"CallBackUrl" => $this->callbackUrl,
            "AdditionalData" => $additionalData,
            "Originator" => $orginator,
	    );
        $params["MultiplexedAccounts"] = $accounts;

        // در این مرحله میتوانید اطلاعات را قبل از ارسال ذخیره سازی کنید.

        $requestData['requestData'] = $params;
        $client = new SoapClient ( $this->url );
        try {
            $result = $client->MultiplexedSaleWithIBANPaymentRequest($requestData);
            if ($result->MultiplexedSaleWithIBANPaymentRequestResult->Token && $result->MultiplexedSaleWithIBANPaymentRequestResult->Status === 0) {
                // توکن دریافت شده را  در این مرحله به تراکنش مورد نظر مرتبط نموده و ذخیره سازی کنید.
                // $token = $result->MultiplexedSaleWithIBANPaymentRequestResult->Token;
                header ( "Location: https://pec.shaparak.ir/NewIPG/?Token=" . $result->MultiplexedSaleWithIBANPaymentRequestResult->Token ); /* Redirect browser */
                exit ();
            }
            elseif ( $result->MultiplexedSaleWithIBANPaymentRequestResult->Status  != '0') {
                $err_msg = "(<strong> کد خطا : " . $result->MultiplexedSaleWithIBANPaymentRequestResult->Status . "</strong>) " .
                $result->MultiplexedSaleWithIBANPaymentRequestResult->Message ;
                $this->errorMsg = $err_msg;
                return false;
            } 
        } catch ( Exception $ex ) {
            $err_msg =  $ex->getMessage();
        }
    }
                        </pre>
                </div>
            </section>


        </div>
    </form>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter-extra.js"></script>
<script src="/js/template.js"></script>
</body>
</html>