<?php
require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res = false;
$success = false;
if ($_POST) {
    if ($_POST['token'] == '' && $_POST['pin'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        $pecRequest->pin = $_POST['pin'];
        // دریافت اطلاعات از فرم
        $token = $_POST['token'];
        
        // ارسال درخواست
        $res = $pecRequest->confirmServices($token);
        if ($res == false) {
            $res = $pecRequest->alertMsg();
        }else{
            $success = true;
        }
    }
    
}



?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">

    <header class="header">
        <div class="d-flex justify-content-center flex-wrap align-items-center h-100">
            <h1 class="header-title">تایید سفارشات پرداخت شده</h1>
        </div>
    </header>

    <!-- منوی سمت راست -->
    <?= include '../sidebar.php' ?>


    <div class="content">
        <?php if ($success == true) : ?>
                <div class="alert alert-success">تراکنش با موفقییت تایید شد.</div>
            <?php else : ?>
                <?= $res ?>
            <?php endif ?>
        <form action="#" id="cancelRequest" name="cancelRequest" method="post" autocomplete="off">
            <div class="d-flex justify-content-between">
                <h3 class="section-title py-2">تایید تراکنش انجام شده </h3>
                <div class="buttons-section col-6 d-flex gap-3 justify-content-end">
                    <button type="sumbit" class="btn btn-success">ارسال اطلاعات</button>
                    <button type="reset" class="btn btn-primary">بازنشانی فرم</button>
                    <button type="button" class="btn btn-warning" onclick="showCode()">نمایش کد ها</button>
                    <a href="https://pgw.pec.ir/IPGDocs/10011101-sw1.pdf" class="btn btn-info">دانلود داکیومنت</a>
                </div>
            </div>
        <div class="container-fluid section-container">
            
            <!-- دریافت اطلاعات از طریق فرم -->
            <section class="col-lg-6 col-12">
                    <div class="form-element col-12">
                        <label for="pin">شناسه پذیرنده (pin) :</label>
                        <input type="text" name="pin" id="pin" class="form-control" data-validation="required" value="<?= (isset($_POST['pin'])) ? $_POST['pin']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                    <div class="alert alert-secondary">شناسه سفارش یکتای دریافتی از طرف بانک را جهت تایید سفارش وارد نمایید</div>
                    <div class="form-element col-12">
                        <label for="pin">شناسه سفارش  (token) :</label>
                        <input type="text" name="token" id="toke" class="form-control" data-validation="required" value="<?= (isset($_POST['pin'])) ? $_POST['token']:'' ?>" />
                        <div class="invalid-feedback">نمیتواند خالی باشد</div>
                    </div>
                
            </section>
       
            <!-- نمایش کد های راهنما -->
            <section class="col-lg-6 col-12 code-viewer-section">
                <div id="source-code-base" class="pr-4">
                    <h4 id="Examples">index.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
        if ($_POST['token'] == '' && $_POST['pin'] == '') {
        $pecRequest->errorMsg = 'لطفا اطلاعات درخواست شده را تکمیل نمایید.';
        $res = $pecRequest->alertMsg();
    }else{
        $pecRequest->pin = $_POST['pin'];
        // دریافت اطلاعات از فرم
        $token = $_POST['token'];
        
        // ارسال درخواست
        $res = $pecRequest->confirmServices($token);
        if ($res == false) {
            $res = $pecRequest->alertMsg();
        }else{
            $success = true;
        }
    }
                        </pre>

                        <h4 id="Examples">PecRequestClass.php</h4>
                        <pre class="code example" data-lllanguage="php" data-llstyle="dark">
                        // سرویس تایید تراکنش
                        public function confirmServices($token){
        $confirmUrl = 'https://pec.shaparak.ir/NewIPGServices/Confirm/ConfirmService.asmx?WSDL';
        $this->url = $confirmUrl;
        $params = array (
            "LoginAccount" => $this->pin,
            "Token" => $token 
        );
        
        $client = new SoapClient ( $this->url );
        
        try {
            $result = $client->ConfirmPayment ( array (
                    "requestData" => $params 
            ) );
            if ($result->ConfirmPaymentResult->Status != '0') {
                // نمایش نتیجه ی پرداخت
                $err_msg = "(<strong> کد خطا : " . $result->ConfirmPaymentResult->Status . "</strong>) ";
                $this->errorMsg = $err_msg;
                return false;
            }
            // پرداخت با موفقییت انجام شده است 
            return true;
        } catch ( Exception $ex ) {
            $err_msg =  $ex->getMessage()  ;
        }
    }

                        </pre>
                </div>
            </section>


        </div>
    </form>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter-extra.js"></script>
<script src="/js/template.js"></script>
</body>
</html>