<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">
    <header class="header">

    </header>

    <?= include './sidebar.php' ?>
    <div class="content">
        <div class="container-fluid">
            <h4>به نسخه دموی سرویس های پرداخت درگاه پارسان خوش آمدید.</h4>
            <div class="requirment">
                <span class="title">لیست پیشنیاز ها</span>
                <ul class="requirement-list">
                    <li class="list-item">php نسخه 5 به بالا  =====> <span class="value">نسخه شما : <?= phpversion() ?></span></li>
                    <li class="list-item">SoapClient class    =====> <span class="value">وضعیت فعال بودن: <?= extension_loaded('soap')? '<i class="bi bi-check-circle-fill text-success"></i>':'<i class="bi bi-x-circle text-danger"></i>' ?></span></li>
                </ul>
            </div>
            
        </div>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>

<script src="/js/template.js"></script>
</body>
</html>