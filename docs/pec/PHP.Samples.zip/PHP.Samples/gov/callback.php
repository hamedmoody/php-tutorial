<?php
require_once '../PecRequestClass.php';

$pecRequest = new PecRequestClass();
$res ='';
$success = false;
if ($_POST) {
	if (isset($_POST["RRN"])) {

		// دریافت اطلاعات برگشتی
		$Token = $_POST ["Token"];
		$status = $_POST ["status"];
		$OrderId = $_POST ["OrderId"];
		$TerminalNo = $_POST ["TerminalNo"];
		$Amount = $_POST ["Amount"];
		$RRN = $_POST ["RRN"];
		if ($RRN > 0 && $status == 0) {
			// پرداخت با موفقییت انجام شده است
			
			// در صورت تایید تراکنش انجام شده توسط کاربر میتواندی از کد زیر استفاده کنید در اینجا ما تراکنش را تایید مینماییم
				$res = $pecRequest->confirmServices($Token);
			// درصورت عدم تایید و انجام تراکنش برگشت میتوانید از کد زیر استفاده کنید
				//$res = $pecRequest->reversalRequest($Token);
			if ($res == true) {
				$success = true;
			}else{
				$res = $pecRequest->alertMsg();
			}
		}elseif($status) {
			$pecRequest->errorMsg = "کد خطای ارسال شده از طرف بانک $status " . "";
			$res = $pecRequest->alertMsg();
		}
	}else{
		$pecRequest->errorMsg  = "انجام تراکنش ناموفق بود." ;
		$res = $pecRequest->alertMsg();
	}
}else {
	$pecRequest->errorMsg  = "پاسخی از سمت بانک ارسال نشده است. " ;
	$res = $pecRequest->alertMsg();
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تجارت الکترونیکی پارسیان</title>

    <link rel="stylesheet" href="/dist/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="/dist/css/bootstrap-icons/bootstrap-icons.css">

    <link rel="stylesheet" href="/css/template.min.css">
</head>
<body class="scrollbar-2">
    <header class="header">
        <div class="d-flex justify-content-center flex-wrap align-items-center h-100">
            <h1 class="header-title">راهنمای ارسال درخواست سرویس خرید کالا</h1>
        </div>
    </header>

    <?= include '../sidebar.php' ?>
    <div class="content">
        <div class="container py-3">
		<div class="code-viewer-section <?= isset($_POST) ? 'active':'' ?>">
			<h4 id="Examples" style="direction:rtl; text-align:right;">مقادیر برگشتی توسط درگاه پرداخت</h4>
                    <pre class="code example" data-lllanguage="php" data-llstyle="dark">
						<?php
							if (isset($_POST)) {
								foreach ($_POST as $key => $value) {
									echo "\r\n".$key.':'.$value;
								}
							}							
						?>
					</pre>
			</div>
			<?php if($success): ?>
				<div class="success-image col-12 d-flex align-items-center h-100 justify-content-center flex-wrap">
					<img src="/images/pay-success.png" alt="success-payment" class="w-50">
					<div class="alert alert-success col-12">پرداخت شما با موفقییت ثبت شد شماره پیگیری : <?= $RRN ?></div>
					<div class="alert alert-success">Token : <?= $Token ?></div>
				</div>
			<?php else: ?>
				<?= $res ?>
			<?php endif;?>
		</div>
    </div>

    <footer class="footer">

    </footer>



<script src="/dist/js/jquery/jquery.min.js"></script>
<script src="/dist/js/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter.js"></script>
<script type="text/javascript" src="/dist/js/code-viewer/jquery-litelighter-extra.js"></script>

<script src="/js/template.js"></script>
</body>
</html>